//Mongoose
const mongoose = require('mongoose');

// Connection URL
mongoose.connect("mongodb://localhost:27017/fruitsDB");
 
 

//create a schema 
const fruitSchema = new mongoose.Schema ({
  name: {
    type: String,
    required: [true, "Check name!"]
  },
    rating: Number,
  review: String
});


//create a model
const Fruit = mongoose.model("Fruit", fruitSchema);

//insert the values
const fruit = new Fruit ({
  name:"Apple",
  rating: 7,
  review: "Preety solid as a fruit."
});


//create a schema 
const personSchema = new mongoose.Schema ({
  name: String,
  rating: Number,
  review: String,

  //embed pineapple
  favouriteFruit: fruitSchema
});

//create a model
const Person = mongoose.model("Person", personSchema);

const pineapple = new Fruit({
  name: "Pineapple",
  score: 9,
  review: "Great",
})

pineapple.save();

const kiwii = new Fruit({
  name: "Kiwii",
  score: 10,
  review: "Best"
});

kiwii.save();


//insert the values
const person = new Person ({
  name:"Satyam",
  rating: 10,
  review: "Good",
  favouriteFruit: pineapple
});
 

//insert the values
const person1 = new Person ({
  name:"john",
  rating: 10,
  review: "Good",
  favouriteFruit: kiwii
});

//save the person
person1.save();

//add 3 fruits
const kiwi = new Fruit({
  name: "Kiwi",
  score: 10,
  review: "Best"
});

const orange = new Fruit({
  name: "Orange",
  score: 10,
  review: "Best"
});

const banana = new Fruit({
  name: "Banana",
  score: 10,
  review: "Good"
});
 
// //update
// Fruit.updateOne({_id: "6367f7b7448d26dd26b2cf40"}, {name: "Peach"}, function(err){
//   if(err){
//     console.log(err);
//   }else {
//     console.log("Successfully updated!");
//     mongoose.connection.close();

//   }
// });

// //delete one
// Fruit.deleteOne({name: "Kiwi"}, function(err){
//   if(err){
//     console.log(err);
//   }else{
//     console.log("Successfully delete One");
//   }
// });

//delete one
// Person.deleteMany({name: "Satyam"}, function(err){
//   if(err){
//     console.log(err);
//   }else{
//     console.log("Successfully delete");
//   }
// });


 
//add all the 3 fruits
// Fruit.insertMany([kiwi,orange,banana], function(err){
//   if(err){
//     console.log(err);
//   }else{
//     console.log("Saved all 3 fruits");
//   }
// });

//find all the fruits
Fruit.find(function(err, fruits){
  if(err) {
    console.log(err); 

  }else { 

    //loop through each fruit
    fruits.forEach(function(fruit){
      console.log(fruit.name);
      mongoose.connection.close(); 

    });
  }
});

 

//save the values
//fruit.save();

//find
const findDocuments = function(db, callback) {
    // Get the documents collection
    const collection = db.collection('fruits');
    // Find some documents
    collection.find({}).toArray(function(err, fruits) {
      assert.equal(err, null);
      console.log("Found the following records");
      console.log(fruits)
      callback(fruits);
    });
  }




































// const mongoose = require('mongoose');

// mongoose.connect("mongodb://localhost:27017/fruitsDB", {useNewUrlParser: true});

// const fruitSchema = new mongoose.Schema({
// name: String,
// rating: Number,
// review: String
// })

// const Fruit = mongoose.model("Fruit", fruitSchema);

// const fruit = new Fruit({
//     name: "Apple",
//     rating: 7,
//     review: "Good"
// });

// fruit.save();
 
// const findDocuments = function(db,callback){
//     //get the doc collectiuon
//     const collection = db.collection('fruits');

//     //find some documents
//     collection.find({}).toArray(function(err, fruits){
//         AuthenticatorAssertionResponse.equal(err,null);
//         console.log("Found the following records");
//         console.log(fruits);
//         callback(fruits);

//     });
// };